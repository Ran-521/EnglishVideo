"""
修复moviepy导入并启动视频编辑器
"""

import os
import sys
import site
import importlib
import traceback

def fix_moviepy():
    """修复moviepy.editor的导入问题"""
    print("正在检查moviepy安装...")
    
    try:
        # 尝试导入moviepy基础模块
        import moviepy
        print(f"找到moviepy版本: {getattr(moviepy, '__version__', '未知')}")
        
        # 检查moviepy安装路径
        moviepy_path = os.path.dirname(moviepy.__file__)
        print(f"Moviepy安装路径: {moviepy_path}")
        
        # 检查editor模块是否存在
        editor_path = os.path.join(moviepy_path, "editor.py")
        if os.path.exists(editor_path):
            print(f"找到editor.py文件: {editor_path}")
        else:
            editor_init_path = os.path.join(moviepy_path, "editor", "__init__.py")
            if os.path.exists(os.path.dirname(editor_init_path)):
                print(f"找到editor包: {os.path.dirname(editor_init_path)}")
            else:
                print("未找到editor模块，可能需要重新安装moviepy")
                # 尝试重新安装moviepy
                print("正在尝试重新安装moviepy...")
                os.system("pip uninstall -y moviepy")
                os.system("pip install moviepy==1.0.3")
                # 刷新导入的模块
                if "moviepy" in sys.modules:
                    del sys.modules["moviepy"]
                    importlib.invalidate_caches()
        
        # 尝试直接从文件导入关键类
        print("正在尝试从moviepy导入关键类...")
        try:
            from moviepy.video.io.VideoFileClip import VideoFileClip
            from moviepy.video.VideoClip import ImageClip, ColorClip
            from moviepy.video.compositing.CompositeVideoClip import CompositeVideoClip
            print("成功导入关键类!")
            return True
        except ImportError as e:
            print(f"导入关键类失败: {e}")
            return False
            
    except ImportError as e:
        print(f"导入moviepy失败: {e}")
        return False

def start_video_editor():
    """启动视频编辑器"""
    try:
        print("正在启动视频编辑器...")
        import video_editor
        app = video_editor.QApplication(sys.argv)
        window = video_editor.VideoEditorApp()
        window.show()
        sys.exit(app.exec_())
    except Exception as e:
        print(f"启动失败: {e}")
        traceback.print_exc()

if __name__ == "__main__":
    if fix_moviepy():
        start_video_editor()
    else:
        print("无法修复moviepy导入问题，程序无法启动")
    
    input("\n按回车键退出...") 