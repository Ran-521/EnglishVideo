"""
调试启动脚本 - 用于检查环境并启动视频编辑器
"""

import sys
import os
import traceback
import platform

def check_environment():
    """检查运行环境"""
    print("=" * 50)
    print("调试信息:")
    print("=" * 50)
    print(f"Python版本: {sys.version}")
    print(f"运行平台: {platform.platform()}")
    print(f"当前目录: {os.getcwd()}")
    print("-" * 50)
    
    # 检查关键依赖
    dependencies = ["numpy", "PIL", "PyQt5", "cv2", "moviepy"]
    for dep in dependencies:
        try:
            module = __import__(dep)
            print(f"{dep} 版本: {getattr(module, '__version__', '未知')}")
        except ImportError as e:
            print(f"{dep} 导入失败: {e}")
    print("-" * 50)

def main():
    """主函数"""
    try:
        # 检查环境
        check_environment()
        
        # 导入视频编辑器模块
        print("正在导入video_editor模块...")
        try:
            import video_editor
            # 启动应用
            print("正在启动应用...")
            # 使用全局变量避免垃圾回收
            global app, window
            app = video_editor.QApplication(sys.argv)
            window = video_editor.VideoEditorApp()
            window.show()
            sys.exit(app.exec_())
        except Exception as e:
            print(f"启动失败: {e}")
            traceback.print_exc()
    except Exception as e:
        print(f"初始化失败: {e}")
        traceback.print_exc()
    
    # 在退出前等待用户按键
    input("\n按回车键退出...")

if __name__ == "__main__":
    main() 